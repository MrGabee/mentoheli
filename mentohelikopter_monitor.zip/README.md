# 🚁 Magyar Mentőhelikopter Monitor

Automatikus e-mail értesítő, amely figyeli a magyarországi mentőhelikopterek
felszállását és leszállását. Teljesen ingyenes, regisztráció nélkül működik.

**Adatforrás:** adsb.fi / adsb.one (ingyenes, nyílt ADS-B hálózat)
**Futtatás:** GitHub Actions (5 percenként, ingyenes)

---

## ⚡ Telepítés (5 perc)

### 1. lépés – Gmail App Password létrehozása

A sima Gmail jelszó nem működik, egy speciális "App Password" kell:

1. Menj: https://myaccount.google.com/security
2. Kapcsold be a **2-lépéses hitelesítést** (ha még nincs bekapcsolva)
3. Menj: https://myaccount.google.com/apppasswords
4. Alkalmazás: **Egyéb** → Írd be: `Mentőhelikopter Monitor`
5. Kattints: **Létrehozás**
6. Másold el a megjelenő **16 karakteres jelszót** (pl. `abcd efgh ijkl mnop`)

### 2. lépés – GitHub repo létrehozása

1. Menj: https://github.com/new
2. Repository neve: `mentohelikopter-monitor`
3. Legyen **Private** (ajánlott, mert Secrets-t tartalmaz)
4. Kattints: **Create repository**

### 3. lépés – Fájlok feltöltése

Töltsd fel a repóba ezt a két fájlt:
- `monitor.py`
- `.github/workflows/monitor.yml`

**Legegyszerűbb módja:**
1. A repo oldalán kattints: **Add file → Upload files**
2. Húzd be a `monitor.py` fájlt
3. Kattints: **Commit changes**
4. Ezután a `.github/workflows/` mappát kézzel kell létrehozni:
   - **Add file → Create new file**
   - Fájlnév mezőbe írd: `.github/workflows/monitor.yml`
   - Másold be a `monitor.yml` tartalmát
   - **Commit changes**

### 4. lépés – Secrets beállítása

1. Repó oldalán: **Settings → Secrets and variables → Actions**
2. Kattints: **New repository secret** – háromszor, ezekkel:

| Név | Érték |
|-----|-------|
| `EMAIL_KULDO` | Gmail címed (pl. `te@gmail.com`) |
| `EMAIL_JELSZO` | Az App Password (szóközök nélkül, pl. `abcdefghijklmnop`) |
| `EMAIL_CIMZETT` | Ahová az értesítést kapni szeretnéd |

### 5. lépés – Első teszt

1. Repó oldalán: **Actions** fül
2. Bal oldalon: **🚁 Mentőhelikopter Monitor**
3. Kattints: **Run workflow → Run workflow**
4. Nézd meg a futás naplóját – ha minden zöld, működik!

---

## ⏱️ Futási gyakoriság

A GitHub Actions minimuma **5 perc**. Ez általában elegendő, mivel a
mentőhelikopterek felszállás után legalább néhány percig repülnek.

Ha mégis 1 perces frissítést szeretnél, az egyik trükk: hozz létre
5 külön workflow fájlt, amelyek 1, 2, 3, 4 perces `sleep` paranccsal
késleltetik egymást ugyanabban az 5 perces ablakban.

---

## 🔧 Testreszabás

A `monitor.py` fájl tetején módosítható:

```python
ISMERT_MENTO_ICAO = {
    "4b1806": "HA-ECO",
    # ... adj hozzá vagy vegyél el gépeket
}
```

Az ICAO24 kódokat ellenőrizheted: https://globe.adsbexchange.com
(keresd meg a HA-EC kezdetű gépeket)

---

## 🆓 Ingyenes korlátok

| Szolgáltatás | Korlát |
|---|---|
| GitHub Actions | 2000 perc/hónap (ingyenes fiókon) |
| adsb.fi API | 1 kérés/másodperc, nincs havi limit |
| Gmail SMTP | Napi ~500 e-mail |

5 perces triggerrel: ~8640 futás/hónap × ~10 másodperc = **~1440 perc/hónap**
→ Bőven az ingyenes 2000 perces kvótán belül. ✅
